#include<iostream>
#include<conio.h>
using namespace std;
int main()
{   int i, coutE=0,count=0;
	int a[5];
	cout<<"  Enter any 5 integers in array \n";
	for(i=0;i<5;i++)
	{
		cout<<"  Enter value at index  "<<i<<"   ";
		cin>>a[i];
	}
	cout<<"values are"<<endl;
	 
 for(i=0;i<5;i++)
{
	cout<<a[i]<<endl;
 
cout <<"array 1 values are :";
for( int i=0; i<5;i++)
{
	if(a[i]%2==0)
	{
		coutE++;
		
	}else{
		cout<<"\n enter the value"<<i+1<<":";
		cin>>a[i];
	}
	cout<<"array 1 values are :";
	for(int i=0;i<5;i++)
	{
		for(int i=0;i<5;i++)
		{
			cout<<a[i]<<"\t";
		}
	}
	for( int i=0; i<5;i++)
	
	{
		if(a[i]%2==0)
		{
			coutE++;
			
		}else {
			count++;
			
		}cout<<"\n numbers of even vales in an array are :"<<coutE<<endl;
		cout<<"numbers of odd values are in array are  :"<<count<<endl; 
		getch();
	}
}


