#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	   int i;
	int a[5];
	cout<<"  Enter any 5 integers in array \n";
	for(i=0;i<5;i++)
	{
		cout<<"  Enter value at index  "<<i<<"   ";
		cin>>a[i];
	}
	cout<<"values are"<<endl;
	 
 for(i=0;i<5;i++)
{
	cout<<a[i]<<endl;
}

for (int i=0;i<5;i++)
{
	if(a[i]%2==0)
	{
		cout<<"even numbers\n "<<a<<i<<"\t";
		
	}
	cout<<"array  values are:";
	for(int i=0;i<5;i++)
	{
		cout<<a[i]<<"\t";
		
	}
}

 for(i=0;i<5;i++)
{
	if(a[i]%2==0)
	{
		cout<<"\n even  :"<<a[i]<<"\t";
		
	}
	else
	{
		cout<<"\n odd :"<<a[i]<<"\t";
    }
    getch();
}
}
