#include<iostream>
#incude<conio.h>
using namespace std;
int main ()
{
	int temp;
	int count =0,count a=0;
	int arr[5];
	cout<<"vaues you want to store in an arary 1";
	for( int i=0;i<5;i++)
	{
		cout<<"\n enter the value"<<i+1<<" :";
		cin>>arr1[i];
		
		
	}cout<<"array1 values are :";
	for(int i=0;i<5;i++)
	{
		cout<<arr1[i]<<"\t";
		
	}
}
//sorting an array in asending order
cout<<"\n after asending the values are";
for(int i=0;i<5;i++)
{
	for(int j=i+1;j<=5;j++)
	{
		cout<<"array 1 values are :";
		for(i=0;i<5;i++)
		
	}
	cout<<"\n after asending the values";
	for(int j=i+1;j<5;)
}
